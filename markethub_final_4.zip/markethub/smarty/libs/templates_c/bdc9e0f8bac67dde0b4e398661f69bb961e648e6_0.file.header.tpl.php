<?php
/* Smarty version 4.2.0, created on 2023-12-12 22:22:13
  from 'C:\xampp\htdocs\markethub\smarty\libs\templates\header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.0',
  'unifunc' => 'content_6578cf0511e801_43577984',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'bdc9e0f8bac67dde0b4e398661f69bb961e648e6' => 
    array (
      0 => 'C:\\xampp\\htdocs\\markethub\\smarty\\libs\\templates\\header.tpl',
      1 => 1702416016,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6578cf0511e801_43577984 (Smarty_Internal_Template $_smarty_tpl) {
?><nav class="navbar navbar-expand-lg bg-info  fixed-top ">
    <div class="container-fluid">
        <img src="/markethub/smarty/libs/images/shop.png" alt="" style="width: 50px"
            class="d-inline-block align-text-top">
        <span class="navbar-brand">MARKET HUB</span>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <style>
                        .btn-outline-dark {
                            border: none;
                            /* Rimuove il bordo predefinito */
                        }

                        .btn-outline-dark:hover {
                            border: 1px solid #343a40;
                            /* Aggiunge il bordo al passaggio del mouse */
                        }
                    </style>

                    <a class="btn btn-info btn-outline-dark" href="/markethub/">Home</a>
                </li>
                <?php if ($_smarty_tpl->tpl_vars['userLogged']->value == 'admin') {?>
                <li class="nav-item">
                    <a class="btn btn-info btn-outline-dark" href="/markethub/Admin/homeAdmin">Admin page</a>
                </li>
                <?php }?>
                <li class="nav-item">
                    <a class="btn btn-info btn-outline-dark" href="/markethub/Contatti/chiSiamo">Chi siamo?</a>
                </li>
                <?php if ($_smarty_tpl->tpl_vars['userLogged']->value == 'admin') {?>
                <li class="nav-item">
                    <a class="btn btn-info btn-outline-dark" methods="POST"
                        href="/markethub/Admin/profiloAdmin">Profilo</a>
                </li>
            </ul>

            <?php if ((isset($_smarty_tpl->tpl_vars['foto_utente']->value))) {?>

            <img src="data:<?php echo $_smarty_tpl->tpl_vars['foto_utente']->value->getTipo();?>
;;base64,<?php echo $_smarty_tpl->tpl_vars['foto_utente']->value->getFoto();?>
" alt=""
                style="width: 30px; margin-right: 6px" class="d-inline-block align-text-right">


            <?php } else { ?>
            <img src="/markethub/smarty/libs/images/login.png" alt="Admin" class="rounded-circle" width="30">

            <?php }?>

            <a class="btn btn-info btn-outline-dark" href="/markethub/Utente/logout">Disconnetti</a>

            <?php } elseif ($_smarty_tpl->tpl_vars['userLogged']->value != 'nouser') {?>
            <li class="nav-item">
                <a class="btn btn-info btn-outline-dark" methods="POST" href="/markethub/Utente/profiloLoggato">Profilo</a>
            </li>

            </ul>

            <?php if ((isset($_smarty_tpl->tpl_vars['foto_utente']->value))) {?>

            <img src="data:<?php echo $_smarty_tpl->tpl_vars['foto_utente']->value->getTipo();?>
;;base64,<?php echo $_smarty_tpl->tpl_vars['foto_utente']->value->getFoto();?>
" alt=""
                style="width: 30px; margin-right: 6px" class="d-inline-block align-text-right">


            <?php } else { ?>
            <img src="/markethub/smarty/libs/images/login.png" alt="Admin" class="rounded-circle" width="30">

            <?php }?>

            <a class="btn btn-info btn-outline-dark" href="/markethub/Utente/logout">Disconnetti</a>

            <?php } else { ?>

            </ul>

            <img src="/markethub/smarty/libs/images/login.png" alt="" style="width: 30px; margin-right: 6px"
                class="d-inline-block align-text-right">
            <a class="btn btn-info btn-outline-dark" href="/markethub/Utente/login">Login/Registrati</a>

            <?php }?>


            <!-- <form class="d-flex" role="search">
                 <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search" >
                 <button class="btn btn-dark" type="submit" >Search</button>
             </form> -->

        </div>
    </div>
</nav><?php }
}
