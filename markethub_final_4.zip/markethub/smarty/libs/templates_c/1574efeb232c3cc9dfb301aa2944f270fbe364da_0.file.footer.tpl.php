<?php
/* Smarty version 4.2.0, created on 2023-12-04 13:11:29
  from 'C:\xampp\htdocs\markethub\smarty\libs\templates\footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.0',
  'unifunc' => 'content_656dc1f18563f2_46165565',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1574efeb232c3cc9dfb301aa2944f270fbe364da' => 
    array (
      0 => 'C:\\xampp\\htdocs\\markethub\\smarty\\libs\\templates\\footer.tpl',
      1 => 1701689084,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_656dc1f18563f2_46165565 (Smarty_Internal_Template $_smarty_tpl) {
?><footer class="bg-info py-4 mt-auto">
  <div class="container px-5">
    <div
      class="row align-items-center justify-content-between flex-column flex-sm-row"
    >
      <div class="col-auto">
        <div class="small m-0">Copyright &copy; Market Hub 2023</div>
      </div>
      <div class="col-auto">
        <a
          class="small"
          style="color: black"
          href="/markethub/Contatti/chiSiamo"
          >Contact</a
        >
      </div>
    </div>
  </div>
</footer>
<?php }
}
