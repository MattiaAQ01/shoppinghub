<?php
/* Smarty version 4.2.0, created on 2023-12-09 11:25:44
  from 'C:\xampp\htdocs\markethub\smarty\libs\templates\tutti_annunci.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.0',
  'unifunc' => 'content_657440a80f0498_59962914',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7ef5ddd84c1e2a378d5c99da187dc1a722b5e679' => 
    array (
      0 => 'C:\\xampp\\htdocs\\markethub\\smarty\\libs\\templates\\tutti_annunci.tpl',
      1 => 1702117485,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_657440a80f0498_59962914 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<?php $_smarty_tpl->_assignInScope('userlogged', (($tmp = $_smarty_tpl->tpl_vars['userlogged']->value ?? null)===null||$tmp==='' ? 'nouser' ?? null : $tmp));
$_smarty_tpl->_assignInScope('searchMod', (($tmp = $_smarty_tpl->tpl_vars['searchMod']->value ?? null)===null||$tmp==='' ? 'searchOff' ?? null : $tmp));?>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Market Hub - Annunci</title>
    <link rel="icon" type="image/x-icon" href="/markethub/smarty/libs/images/shop.png" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
    <link href="/markethub/smarty/libs/css/boot_styles.css" rel="stylesheet" />
</head>

<style>
    .container1 {
        display: flex;
        justify-content: space-around;
        /* o altri valori come center o flex-start */
    }

    .image-container {

        border: 1px solid #ddd;
        box-sizing: border-box;
        padding: 10px;
        margin: 10px;
        text-align: center;
        height: 500px;
        display: flex;
        flex-wrap: wrap;
        gap: 20px;
        flex-direction: column;
        object-fit: cover;
        overflow: hidden;

    }


    .image-container img {
        width: 100%;
        height: auto;
        display: block;
        max-height: 300px;
    }

    .image-container:hover img {
        transform: scale(1.1);
    }

    .description {
        padding: 30px;
        flex: 1;
        box-sizing: border-box;
        position: relative;
    }
</style>

<?php $_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<body>


    <!-- Page top -->
    <header class="py-5 bg-info border-bottom mb-4">
        <div class="container">
            <div class="text-center my-5">
                <h1 class="fw-bolder">Benvenuto negli annunci</h1>
                <p class="lead mb-0">Esplora gli annunci che ti appassionano di più
                    <!doctype html>
                    <html lang="en">

                    <head>
                        <meta charset="UTF-8">
                        <meta name="viewport"
                            content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
                        <meta http-equiv="X-UA-Compatible" content="ie=edge">
                        <title>Document</title>
                    </head>

                    <body>

                    </body>

                    </html>
                </p>
            </div>
        </div>
    </header>
    <!-- Page content-->
    <div class="container">
        <?php if (!is_array($_smarty_tpl->tpl_vars['immagini']->value) && !is_array($_smarty_tpl->tpl_vars['annunci']->value)) {?>
        <div class="row">
            <!-- Blog entries-->
            <div class="col-lg-8">
                <!-- Featured blog post-->
                <div class="card mb-4">
                    <a href="/markethub/Annunci/infoAnnuncio/<?php echo $_smarty_tpl->tpl_vars['annunci']->value[0]->getIdAnnuncio();?>
"><img class="card-img-top"
                            src="data:<?php echo $_smarty_tpl->tpl_vars['immagini']->value[0][0]->getTipo();?>
;base64,<?php echo $_smarty_tpl->tpl_vars['immagini']->value[0][0]->getFoto();?>
" alt="..." /></a>
                    <div class="card-body">
                        <h2 class="card-title"><?php echo $_smarty_tpl->tpl_vars['annunci']->value->getTitolo();?>
</h2>
                        <p class="card-text"><?php echo substr($_smarty_tpl->tpl_vars['annunci']->value->getDescrizione(),0,100);?>
...</p>
                        <div class="small text-muted"><?php echo $_smarty_tpl->tpl_vars['annunci']->value->getData();?>
 &middot;
                        </div>
                    </div>
                </div>
                <?php } else { ?>
                <div class="row">
                    <!-- widgets-->
                    <div class="col-lg-4 offset-lg-4">
                    <div class="d-flex justify-content-between">
                        <!-- Search widget-->
                        <div class="card mb-4">
                            <div class="card-header">Cerca</div>
                            <div class="card-body">
                                <form method="POST" action="/markethub/Annunci/cerca">
                                    <div class="input-group">
                                        <input class="form-control" name="text" type="text"
                                            placeholder="Inserisci termine di ricerca..."
                                            aria-label="Enter search term..." aria-describedby="button-search" />
                                        <button class="btn btn-primary" id="button-search" type="submit">Cerca</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <!-- Categories widget-->
                        <div class="card mb-4">
                            <div class="card-header">Categorie</div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-sm-6 dropdown">
                                        <button class="btn btn-primary dropdown-toggle" type="button"
                                            data-bs-toggle="dropdown" aria-expanded="false">Categorie</button>
                                        <ul class="dropdown-menu">
                                            <?php if ($_smarty_tpl->tpl_vars['categorie']->value != null) {?>
                                            <?php if (is_array($_smarty_tpl->tpl_vars['categorie']->value)) {?>
                                            <?php
$_smarty_tpl->tpl_vars['i'] = new Smarty_Variable(null, $_smarty_tpl->isRenderingCache);
$_smarty_tpl->tpl_vars['i']->value = 0;
if ($_smarty_tpl->tpl_vars['i']->value < sizeof($_smarty_tpl->tpl_vars['categorie']->value)) {
for ($_foo=true;$_smarty_tpl->tpl_vars['i']->value < sizeof($_smarty_tpl->tpl_vars['categorie']->value); $_smarty_tpl->tpl_vars['i']->value++) {
?> <li><a class="dropdown-item"
                                                    href="/markethub/Annunci/cerca?categoria=<?php echo $_smarty_tpl->tpl_vars['categorie']->value[$_smarty_tpl->tpl_vars['i']->value]->getIdCate();?>
"><?php echo $_smarty_tpl->tpl_vars['categorie']->value[$_smarty_tpl->tpl_vars['i']->value]->getCategoria();?>
</a>
                                                </li>
                                                <?php }
}
?>
                                        </ul>
                                    </div>
                                    <?php } else { ?>
                                    <li><a
                                            href="/markethub/Annunci/cerca?categoria=<?php echo $_smarty_tpl->tpl_vars['categorie']->value->getIdCate();?>
"><?php echo $_smarty_tpl->tpl_vars['categorie']->value->getCategoria();?>
</a>
                                    </li>
                                    </ul>
                                </div>
                                <?php }?>
                                <?php }?>
                            </div>
                        </div>
                        </div>
                    </div>
                    </div>
                    <!-- Blog entries-->
                    <div class="row justify-content-center">
                    <div class="col-lg-6">
                        <!-- Featured blog post-->
                        <div class="card mb-4">
                            <a href="/markethub/Annunci/infoAnnuncio/<?php echo $_smarty_tpl->tpl_vars['annunci']->value[0]->getIdAnnuncio();?>
"><img
                                    class="card-img-top"
                                    src="data:<?php echo $_smarty_tpl->tpl_vars['immagini']->value[0][0]->getTipo();?>
;base64,<?php echo $_smarty_tpl->tpl_vars['immagini']->value[0][0]->getFoto();?>
"
                                    alt="..." /></a>
                            <div class="card-body">
                                <h2 class="card-title"><?php echo $_smarty_tpl->tpl_vars['annunci']->value[0]->getTitolo();?>
</h2>
                                <p class="card-text"><?php echo substr($_smarty_tpl->tpl_vars['annunci']->value[0]->getDescrizione(),0,100);?>
...</p>
                                <div class="small text-muted"><?php echo $_smarty_tpl->tpl_vars['annunci']->value[0]->getData();?>
 &middot;
                                </div>
                            </div>
                        </div>
                        <!-- Nested row for non-featured blog posts-->
                        <div class="container1">
                            <div class="col-lg-6">
                                <!-- Blog post-->
                                <?php if (count($_smarty_tpl->tpl_vars['annunci']->value) >= 2) {?>
                                <div class="image-container">
                                    <a href="/markethub/Annunci/infoAnnuncio/<?php echo $_smarty_tpl->tpl_vars['annunci']->value[1]->getIdAnnuncio();?>
"><img
                                            class="card-img-top"
                                            src="data:<?php echo $_smarty_tpl->tpl_vars['immagini']->value[1][0]->getTipo();?>
;base64,<?php echo $_smarty_tpl->tpl_vars['immagini']->value[1][0]->getFoto();?>
"
                                            alt="..." /></a>
                                    <div class="description">
                                        <h2 class="card-title h4"><?php echo $_smarty_tpl->tpl_vars['annunci']->value[1]->getTitolo();?>
</h2>
                                        <p class="card-text"><?php echo substr($_smarty_tpl->tpl_vars['annunci']->value[1]->getDescrizione(),0,100);?>
...</p>
                                        <div class="small text-muted"><?php echo $_smarty_tpl->tpl_vars['annunci']->value[1]->getData();?>
 &middot;
                                        </div>
                                    </div>
                                </div>
                                <?php }?>
                                <!-- Blog post-->
                                <?php if (count($_smarty_tpl->tpl_vars['annunci']->value) >= 3) {?>
                                <div class="image-container">
                                    <a href="/markethub/Annunci/infoAnnuncio/<?php echo $_smarty_tpl->tpl_vars['annunci']->value[2]->getIdAnnuncio();?>
"><img
                                            class="card-img-top"
                                            src="data:<?php echo $_smarty_tpl->tpl_vars['immagini']->value[2][0]->getTipo();?>
;base64,<?php echo $_smarty_tpl->tpl_vars['immagini']->value[2][0]->getFoto();?>
"
                                            alt="..." /></a>
                                    <div class="description">
                                        <h2 class="card-title h4"><?php echo $_smarty_tpl->tpl_vars['annunci']->value[2]->getTitolo();?>
</h2>
                                        <p class="card-text"><?php echo substr($_smarty_tpl->tpl_vars['annunci']->value[2]->getDescrizione(),0,100);?>
...</p>
                                        <div class="small text-muted"><?php echo $_smarty_tpl->tpl_vars['annunci']->value[2]->getData();?>
 &middot;
                                        </div>
                                    </div>
                                </div>
                                <?php }?>
                            </div>
                            <div class="col-lg-6">
                                <!-- Blog post-->
                                <?php if (count($_smarty_tpl->tpl_vars['annunci']->value) >= 4) {?>
                                <div class="image-container">
                                    <a href="/markethub/Annunci/infoAnnuncio/<?php echo $_smarty_tpl->tpl_vars['annunci']->value[3]->getIdAnnuncio();?>
"><img
                                            class="card-img-top"
                                            src="data:<?php echo $_smarty_tpl->tpl_vars['immagini']->value[3][0]->getTipo();?>
;base64,<?php echo $_smarty_tpl->tpl_vars['immagini']->value[3][0]->getFoto();?>
"
                                            alt="..." /></a>
                                    <div class="description">
                                        <h2 class="card-title h4"><?php echo $_smarty_tpl->tpl_vars['annunci']->value[3]->getTitolo();?>
</h2>
                                        <p class="card-text"><?php echo substr($_smarty_tpl->tpl_vars['annunci']->value[3]->getDescrizione(),0,100);?>
...</p>
                                        <div class="small text-muted"><?php echo $_smarty_tpl->tpl_vars['annunci']->value[3]->getData();?>
 &middot;
                                        </div>
                                    </div>
                                </div>
                                <?php }?>
                                <!-- Blog post-->
                                <?php if (count($_smarty_tpl->tpl_vars['annunci']->value) == 5) {?>
                                <div class="image-container">
                                    <a href="/markethub/Annunci/infoAnnuncio/<?php echo $_smarty_tpl->tpl_vars['annunci']->value[4]->getIdAnnuncio();?>
"><img
                                            class="card-img-top"
                                            src="data:<?php echo $_smarty_tpl->tpl_vars['immagini']->value[4][0]->getTipo();?>
;base64,<?php echo $_smarty_tpl->tpl_vars['immagini']->value[4][0]->getFoto();?>
"
                                            alt="..." /></a>
                                    <div class="description">
                                        <h2 class="card-title h4"><?php echo $_smarty_tpl->tpl_vars['annunci']->value[4]->getTitolo();?>
</h2>
                                        <p class="card-text"><?php echo substr($_smarty_tpl->tpl_vars['annunci']->value[4]->getDescrizione(),0,100);?>
...</p>
                                        <div class="small text-muted"><?php echo $_smarty_tpl->tpl_vars['annunci']->value[4]->getData();?>
 &middot;
                                        </div>
                                    </div>
                                </div>
                                <?php }?>
                            </div>
                        </div>
                        <?php }?>
                        <!-- Pagination-->
                        <nav aria-label="Pagination">
                            <hr class="my-0" />
                            <ul class="pagination justify-content-center my-4">
                                <?php if ($_smarty_tpl->tpl_vars['searchMod']->value == 'searchOff') {?>
                                <?php if ($_smarty_tpl->tpl_vars['index']->value == 1) {?>
                                <li class="page-item disabled"><a class="page-link" href="#" tabindex="-1"
                                        aria-disabled="true">Back</a></li>
                                <li class="page-item active" aria-current="page"><a class="page-link"
                                        href="/markethub/Annunci/esploraAnnunci//<?php echo $_smarty_tpl->tpl_vars['index']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['index']->value;?>
</a></li>
                                <?php if ($_smarty_tpl->tpl_vars['index']->value+1 < $_smarty_tpl->tpl_vars['num_pagine']->value) {?> <li class="page-item"><a class="page-link"
                                        href="/markethub/Annunci/esploraAnnunci//<?php echo $_smarty_tpl->tpl_vars['index']->value+1;?>
"><?php echo $_smarty_tpl->tpl_vars['index']->value+1;?>
</a></li>
                                    <?php }?>
                                    <?php if ($_smarty_tpl->tpl_vars['index']->value+2 < $_smarty_tpl->tpl_vars['num_pagine']->value) {?> <li class="page-item"><a class="page-link"
                                            href="/markethub/Annunci/esploraAnnunci//<?php echo $_smarty_tpl->tpl_vars['index']->value+2;?>
"><?php echo $_smarty_tpl->tpl_vars['index']->value+2;?>
</a></li>
                                        <?php }?>
                                        <?php } else { ?>
                                        <li class="page-item"><a class="page-link"
                                                href="/markethub/Annunci/esploraAnnunci//<?php echo $_smarty_tpl->tpl_vars['index']->value-1;?>
" tabindex="-1"
                                                aria-disabled="true">Back</a></li>
                                        <li class="page-item" aria-current="page"><a class="page-link"
                                                href="/markethub/Annunci/esploraAnnunci//<?php echo $_smarty_tpl->tpl_vars['index']->value-1;?>
"><?php echo $_smarty_tpl->tpl_vars['index']->value-1;?>
</a>
                                        </li>
                                        <li class="page-item active"><a class="page-link"
                                                href="/markethub/Annunci/esploraAnnunci//<?php echo $_smarty_tpl->tpl_vars['index']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['index']->value;?>
</a></li>
                                        <?php if ($_smarty_tpl->tpl_vars['index']->value+1 < $_smarty_tpl->tpl_vars['num_pagine']->value) {?> <li class="page-item"><a class="page-link"
                                                href="/markethub/Annunci/esploraAnnunci//<?php echo $_smarty_tpl->tpl_vars['index']->value+1;?>
"><?php echo $_smarty_tpl->tpl_vars['index']->value+1;?>
</a>
                                            </li>
                                            <?php }?>
                                            <?php }?>
                                            <?php if ($_smarty_tpl->tpl_vars['num_pagine']->value <= $_smarty_tpl->tpl_vars['index']->value+1 && $_smarty_tpl->tpl_vars['num_pagine']->value != $_smarty_tpl->tpl_vars['index']->value) {?> <li
                                                class="page-item"><a class="page-link"
                                                    href="/markethub/Annunci/esploraAnnunci//<?php echo $_smarty_tpl->tpl_vars['num_pagine']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['num_pagine']->value;?>
</a>
                                                </li>
                                                <?php } elseif ($_smarty_tpl->tpl_vars['index']->value < $_smarty_tpl->tpl_vars['num_pagine']->value-1) {?> <li class="page-item disabled"><a
                                                        class="page-link" href="#!">...</a></li>
                                                    <li class="page-item"><a class="page-link"
                                                            href="/markethub/Annunci/esploraAnnunci//<?php echo $_smarty_tpl->tpl_vars['num_pagine']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['num_pagine']->value;?>
</a>
                                                    </li>
                                                    <?php }?>
                                                    <?php if ($_smarty_tpl->tpl_vars['num_pagine']->value >= $_smarty_tpl->tpl_vars['index']->value+1) {?>
                                                    <li class="page-item"><a class="page-link"
                                                            href="/markethub/Annunci/esploraAnnunci//<?php echo $_smarty_tpl->tpl_vars['index']->value+1;?>
">Next</a>
                                                    </li>
                                                    <?php } else { ?>
                                                    <li class="page-item disabled"><a class="page-link"
                                                            href="/markethub/Annunci/esploraAnnunci//<?php echo $_smarty_tpl->tpl_vars['index']->value+1;?>
">Next</a>
                                                    </li>
                                                    <?php }?>
                                                    <?php } else { ?>
                                                    <?php if ($_smarty_tpl->tpl_vars['index']->value == 1) {?>
                                                    <li class="page-item disabled"><a class="page-link" href="#"
                                                            tabindex="-1" aria-disabled="true">Back</a></li>
                                                    <li class="page-item active" aria-current="page"><a
                                                            class="page-link"
                                                            href="/markethub/Annunci/esploraAnnunci/cerca/<?php echo $_smarty_tpl->tpl_vars['index']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['index']->value;?>
</a>
                                                    </li>
                                                    <?php if ($_smarty_tpl->tpl_vars['index']->value+1 < $_smarty_tpl->tpl_vars['num_pagine']->value) {?> <li class="page-item"><a
                                                            class="page-link"
                                                            href="/markethub/Annunci/esploraAnnunci/cerca/<?php echo $_smarty_tpl->tpl_vars['index']->value+1;?>
"><?php echo $_smarty_tpl->tpl_vars['index']->value+1;?>
</a></li>
                                                        <?php }?>
                                                        <?php if ($_smarty_tpl->tpl_vars['index']->value+2 < $_smarty_tpl->tpl_vars['num_pagine']->value) {?> <li class="page-item"><a
                                                                class="page-link"
                                                                href="/markethub/Annunci/esploraAnnunci/cerca/<?php echo $_smarty_tpl->tpl_vars['index']->value+2;?>
"><?php echo $_smarty_tpl->tpl_vars['index']->value+2;?>
</a></li>
                                                            <?php }?>
                                                            <?php } else { ?>
                                                            <li class="page-item"><a class="page-link"
                                                                    href="/markethub/Annunci/esploraAnnunci/cerca/<?php echo $_smarty_tpl->tpl_vars['index']->value-1;?>
"
                                                                    tabindex="-1" aria-disabled="true">Back</a></li>
                                                            <li class="page-item" aria-current="page"><a
                                                                    class="page-link"
                                                                    href="/markethub/Annunci/esploraAnnunci/cerca/<?php echo $_smarty_tpl->tpl_vars['index']->value-1;?>
"><?php echo $_smarty_tpl->tpl_vars['index']->value-1;?>
</a></li>
                                                            <li class="page-item active"><a class="page-link"
                                                                    href="/markethub/Annunci/esploraAnnunci/cerca/<?php echo $_smarty_tpl->tpl_vars['index']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['index']->value;?>
</a>
                                                            </li>
                                                            <?php if ($_smarty_tpl->tpl_vars['index']->value+1 < $_smarty_tpl->tpl_vars['num_pagine']->value) {?> <li class="page-item"><a
                                                                    class="page-link"
                                                                    href="/markethub/Annunci/esploraAnnunci/cerca/<?php echo $_smarty_tpl->tpl_vars['index']->value+1;?>
"><?php echo $_smarty_tpl->tpl_vars['index']->value+1;?>
</a></li>
                                                                <?php }?>
                                                                <?php }?>
                                                                <?php if ($_smarty_tpl->tpl_vars['num_pagine']->value <= $_smarty_tpl->tpl_vars['index']->value+1 && $_smarty_tpl->tpl_vars['num_pagine']->value != $_smarty_tpl->tpl_vars['index']->value) {?>
                                                                    <li class="page-item"><a class="page-link"
                                                                        href="/markethub/Annunci/esploraAnnunci/cerca/<?php echo $_smarty_tpl->tpl_vars['num_pagine']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['num_pagine']->value;?>
</a>
                                                                    </li>
                                                                    <?php } elseif ($_smarty_tpl->tpl_vars['index']->value < $_smarty_tpl->tpl_vars['num_pagine']->value-1) {?> <li
                                                                        class="page-item disabled"><a class="page-link"
                                                                            href="#!">...</a></li>
                                                                        <li class="page-item"><a class="page-link"
                                                                                href="/markethub/Annunci/esploraAnnunci/cerca/<?php echo $_smarty_tpl->tpl_vars['num_pagine']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['num_pagine']->value;?>
</a>
                                                                        </li>
                                                                        <?php }?>
                                                                        <?php if ($_smarty_tpl->tpl_vars['num_pagine']->value >= $_smarty_tpl->tpl_vars['index']->value+1) {?>
                                                                        <li class="page-item"><a class="page-link"
                                                                                href="/markethub/Annunci/esploraAnnunci/cerca/<?php echo $_smarty_tpl->tpl_vars['index']->value+1;?>
">Next</a>
                                                                        </li>
                                                                        <?php } else { ?>
                                                                        <li class="page-item disabled"><a
                                                                                class="page-link"
                                                                                href="/markethub/Annunci/esploraAnnunci/cerca/<?php echo $_smarty_tpl->tpl_vars['index']->value+1;?>
">Next</a>
                                                                        </li>
                                                                        <?php }?>
                                                                        <?php }?>
                            </ul>
                        </nav>
                    </div>
                    </div>
                </div>
            </div>
        </div>
        <?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
        <!-- Bootstrap core JS-->
        <?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"><?php echo '</script'; ?>
>
        <!-- Core theme JS-->
        <?php echo '<script'; ?>
 src="js/scripts.js"><?php echo '</script'; ?>
>
</body>

</html><?php }
}
