<?php
/* Smarty version 4.2.0, created on 2023-12-12 16:02:13
  from 'C:\xampp\htdocs\markethub\smarty\libs\templates\storico.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.0',
  'unifunc' => 'content_657875f5f03aa7_31255716',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '828be7045d340c84506a74d7b120a3b21bef2b3a' => 
    array (
      0 => 'C:\\xampp\\htdocs\\markethub\\smarty\\libs\\templates\\storico.tpl',
      1 => 1702393203,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
  ),
),false)) {
function content_657875f5f03aa7_31255716 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Market Hub - Storico</title>
    <link rel="icon" type="image/x-icon" href="/markethub/smarty/libs/images/shop.png" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link href="/markethub/smarty/libs/css/style.css">
</head>

<body>


    <?php $_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <section class="h-100 gradient-custom">
        <div class="container py-5 h-100">
            <div class="row d-flex justify-content-center align-items-center h-100">
                <div class="col-lg-10 col-xl-8">
                    <div class="card" style="border-radius: 10px;">
                        <div class="card-header px-4 py-5">
                            <h5 class="text-muted mb-0">Storico di, <span style="color: #a8729a;"><?php echo $_smarty_tpl->tpl_vars['utente']->value->getNome();?>
</span>!</h5>
                                    
                        </div>
                        <div class="card-body p-4">
                            <div class="d-flex justify-content-between align-items-center mb-4">
                            </div>
                            <!-- inizio annuncio -->
                            <?php if ((isset($_smarty_tpl->tpl_vars['annuncio']->value))) {?>
                            <?php
$_smarty_tpl->tpl_vars['i'] = new Smarty_Variable(null, $_smarty_tpl->isRenderingCache);
$_smarty_tpl->tpl_vars['i']->value = 0;
if ($_smarty_tpl->tpl_vars['i']->value < count($_smarty_tpl->tpl_vars['annuncio']->value)) {
for ($_foo=true;$_smarty_tpl->tpl_vars['i']->value < count($_smarty_tpl->tpl_vars['annuncio']->value); $_smarty_tpl->tpl_vars['i']->value++) {
?> <div class="card shadow-0 border mb-4">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-2">
                                            <img class="card-img-top "
                                                src="data:<?php echo $_smarty_tpl->tpl_vars['immagini']->value[$_smarty_tpl->tpl_vars['i']->value][0]->getTipo();?>
;base64,<?php echo $_smarty_tpl->tpl_vars['immagini']->value[$_smarty_tpl->tpl_vars['i']->value][0]->getFoto();?>
"
                                                style="width: 100px;height: 100px;object-fit: contain" />

                                        </div>
                                        <div
                                            class="col-md-2 text-center d-flex justify-content-center align-items-center">
                                            <p class="text-muted mb-0"><?php echo $_smarty_tpl->tpl_vars['annuncio']->value[$_smarty_tpl->tpl_vars['i']->value]->getTitolo();?>
</p>
                                        </div>
                                        <div
                                            class="col-md-2 text-center d-flex justify-content-center align-items-center">
                                            <p class="text-muted mb-0 small"><?php echo $_smarty_tpl->tpl_vars['annuncio']->value[$_smarty_tpl->tpl_vars['i']->value]->getPrezzo();?>
 €</p>
                                        </div>
                                        <!--aggiungere data acquisto-->
                                    </div>

                                </div>
                        </div>
                        <?php }
}
?>
                        <?php } else { ?>
                        <p>Nessun annuncio acquistato</p>

                        <?php }?>

                    </div>


                </div> <!-- fine annuncio-->


                <a href="/markethub/">torno alla home</a>
            </div>
        </div>
        </div>
        </div>
    </section>
    <?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4"
        crossorigin="anonymous"><?php echo '</script'; ?>
>

</body>

</html><?php }
}
