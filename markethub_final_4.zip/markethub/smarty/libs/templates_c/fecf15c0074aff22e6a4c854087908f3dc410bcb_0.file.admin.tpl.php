<?php
/* Smarty version 4.2.0, created on 2023-12-07 17:02:03
  from 'C:\xampp\htdocs\markethub\smarty\libs\templates\admin.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.0',
  'unifunc' => 'content_6571ec7b386845_72329073',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'fecf15c0074aff22e6a4c854087908f3dc410bcb' => 
    array (
      0 => 'C:\\xampp\\htdocs\\markethub\\smarty\\libs\\templates\\admin.tpl',
      1 => 1701689026,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_6571ec7b386845_72329073 (Smarty_Internal_Template $_smarty_tpl) {
?><!doctype html>
<?php $_smarty_tpl->_assignInScope('userLogged', (($tmp = $_smarty_tpl->tpl_vars['userLogged']->value ?? null)===null||$tmp==='' ? 'nouser' ?? null : $tmp));?>

<html lang="en" xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html" />

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Market Hub - Amministratore</title>
    <link rel="icon" type="image/x-icon" href="/markethub/smarty/libs/images/shop.png" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <link href="/markethub/smarty/libs/css/style.css" rel="stylesheet" />
    <?php echo '<script'; ?>
 src="https://code.jquery.com/jquery-1.10.2.js"><?php echo '</script'; ?>
>
</head>

<body>



    <?php $_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <div class="padding">
        <div class="d-flex">
            <div class="ms-3">
                <h3 class="m-b-0"><?php echo $_smarty_tpl->tpl_vars['utente']->value->getNome();?>
 <?php echo $_smarty_tpl->tpl_vars['utente']->value->getCognome();?>
</h3>
                <p class="text-muted">Amministratore</p>
            </div>
        </div>
    </div>
    <h2 class="text-center fw-bolder fs-5 mb-4 padding">Lista membri
        <input type="text" id="SearchTxt" /><input type="button" id="SearchBtn" value="Cerca"
            onclick="doSearch(document.getElementById('SearchTxt').value)" />
    </h2>
    <section class="py-5">
        <div class="container px-5">
            <?php echo '<script'; ?>
>
                function doSearch(text) {
                    if (window.find(text)) {
                        console.log(window.find(text));
                    }
                }
            <?php echo '</script'; ?>
>

            <div class="row gx-5" id="list">

                <?php if ($_smarty_tpl->tpl_vars['list']->value) {?>
                <?php if (is_array($_smarty_tpl->tpl_vars['list']->value)) {?>
                <?php
$_smarty_tpl->tpl_vars['i'] = new Smarty_Variable(null, $_smarty_tpl->isRenderingCache);
$_smarty_tpl->tpl_vars['i']->value = 0;
if ($_smarty_tpl->tpl_vars['i']->value < sizeof($_smarty_tpl->tpl_vars['list']->value)) {
for ($_foo=true;$_smarty_tpl->tpl_vars['i']->value < sizeof($_smarty_tpl->tpl_vars['list']->value); $_smarty_tpl->tpl_vars['i']->value++) {
?> <div class="col-lg-4 mb-5">
                    <div class="card h-100 shadow border-0">
                        <div class="card-body p-4">
                            <a href="/markethub/Admin/profiloUtente?id=<?php echo $_smarty_tpl->tpl_vars['list']->value[$_smarty_tpl->tpl_vars['i']->value]->getIdUser();?>
"><?php echo $_smarty_tpl->tpl_vars['list']->value[$_smarty_tpl->tpl_vars['i']->value]->getNome();?>

                                <?php echo $_smarty_tpl->tpl_vars['list']->value[$_smarty_tpl->tpl_vars['i']->value]->getCognome();?>
</a>
                        </div>
                    </div>
            </div>
            <?php }
}
?>
            <?php }?>
            <?php } else { ?>
            <h2> Non ci sono membri iscritti </h2>
            <?php }?>
        </div>
        </div>
    </section>
    <?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
</body>

</html><?php }
}
