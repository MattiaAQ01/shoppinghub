<?php
/* Smarty version 4.2.0, created on 2023-12-13 12:22:42
  from 'C:\xampp\htdocs\markethub\smarty\libs\templates\annuncio_privato.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.0',
  'unifunc' => 'content_6579940239bdd0_61234293',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '54f93dcb00cca791bae017f92f20ce90ab5cc5ef' => 
    array (
      0 => 'C:\\xampp\\htdocs\\markethub\\smarty\\libs\\templates\\annuncio_privato.tpl',
      1 => 1702466488,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_6579940239bdd0_61234293 (Smarty_Internal_Template $_smarty_tpl) {
?><!doctype html>
<?php $_smarty_tpl->_assignInScope('userLogged', (($tmp = $_smarty_tpl->tpl_vars['userLogged']->value ?? null)===null||$tmp==='' ? 'nouser' ?? null : $tmp));?>

<html lang="en" xmlns="http://www.w3.org/1999/html">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Market Hub - Annuncio</title>
    <link rel="icon" type="image/x-icon" href="/markethub/smarty/libs/images/shop.png" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <link href="markethub/smarty/libs/css/style.css" rel="stylesheet">
    <?php echo '<script'; ?>
 src="https://code.jquery.com/jquery-1.10.2.js"><?php echo '</script'; ?>
>


</head>
<body>




<?php $_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<br>
<div class="container" >
    <section>
        <div class="container text-center" style="display: block;margin-left: 25%;">

            <div class="row">


                <div class="col">
                    <div class="container py-5">
                        <div class="row justify-content-center">
                            <div class="col-md-8 col-lg-6 col-xl-4">
                                <div class="card" style="border-radius: 15px;">
                                    <!-- replica il codice finchè per n argomenti array -->
                                    <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="true">

                                        <?php if (is_array($_smarty_tpl->tpl_vars['foto']->value)) {?>
                                        <div class="carousel-inner">

                                            <div class="carousel-item active">
                                                <img  class="card-img-top " src="data:<?php echo $_smarty_tpl->tpl_vars['foto']->value[0]->getTipo();?>
;base64,<?php echo $_smarty_tpl->tpl_vars['foto']->value[0]->getFoto();?>
" style="width: 300px;height: 300px;object-fit: contain"   />

                                            </div>
                                            <?php
$_smarty_tpl->tpl_vars['i'] = new Smarty_Variable(null, $_smarty_tpl->isRenderingCache);
$_smarty_tpl->tpl_vars['i']->value = 1;
if ($_smarty_tpl->tpl_vars['i']->value < sizeof($_smarty_tpl->tpl_vars['foto']->value)) {
for ($_foo=true;$_smarty_tpl->tpl_vars['i']->value < sizeof($_smarty_tpl->tpl_vars['foto']->value); $_smarty_tpl->tpl_vars['i']->value++) {
?>
                                                <div class="carousel-item ">
                                                    <img  class="card-img-top " src="data:<?php echo $_smarty_tpl->tpl_vars['foto']->value[$_smarty_tpl->tpl_vars['i']->value]->getTipo();?>
;base64,<?php echo $_smarty_tpl->tpl_vars['foto']->value[$_smarty_tpl->tpl_vars['i']->value]->getFoto();?>
" style="width: 300px;height: 300px;object-fit: contain"   />

                                                </div>
                                            <?php }
}
?>

                                        </div>
                                        <button class="carousel-control-prev"  type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
                                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                            <span class="visually-hidden">Previous</span>
                                        </button>
                                        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
                                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                            <span class="visually-hidden">Next</span>
                                        </button>
                                    </div>


                                    <?php }?>




                                    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev" >
                                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                        <span class="visually-hidden">Previous</span>
                                    </button>
                                    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
                                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                        <span class="visually-hidden">Next</span>
                                    </button>

                                    <div class="card-body pb-0">
                                        <div class="d-flex justify-content-between">
                                            <div>
                                                <p><a href="#!" class="text-dark"><?php echo $_smarty_tpl->tpl_vars['annuncio']->value->getTitolo();?>
</a></p>
                                                <p class="small text-muted"><?php echo $_smarty_tpl->tpl_vars['categoria']->value->getCategoria();?>
</p>
                                            </div>
                                            <div>
                                                <div class="d-flex flex-row justify-content-end mt-1 mb-4 text-danger">
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <hr class="my-0" />
                                    <div class="card-body pb-0">
                                        <div class="d-flex justify-content-between">
                                            <p><a href="#!" class="text-dark">Prezzo <?php echo $_smarty_tpl->tpl_vars['annuncio']->value->getPrezzo();?>
€</a></p>
                                        </div>
                                    </div>
                                    <hr class="my-0" >
                                    <div class="card-body pb-0">
                                        <div class="justify-content-between">
                                            <p><a href="#!" class="text-dark">Descrizione</a></p>

                                            <p class="text-dark"><?php echo $_smarty_tpl->tpl_vars['annuncio']->value->getDescrizione();?>
</p>
                                        </div>
                                    </div>

                                    <hr class="my-0" />
                                    <div class="card-body">
                                        <?php if ($_smarty_tpl->tpl_vars['mod']->value == null) {?>

                                            <div class="d-flex justify-content-between align-items-center pb-2 mb-1">
                                                <a  href="/markethub/Utente/login" class="btn btn-primary" style="margin: auto; width: 50%">Iscriviti</a>

                                            </div>
                                        <?php } elseif ($_smarty_tpl->tpl_vars['annuncio']->value->isAcquistato() == 1) {?>
                                            <div class="d-flex justify-content-between align-items-center pb-2 mb-1">
                                                <a type="button" style="margin: auto; width: 50%" class="btn btn-primary">Venduto</a>
                                            </div>
                                        <?php } elseif ($_smarty_tpl->tpl_vars['mod']->value->getIdUser() != $_smarty_tpl->tpl_vars['annuncio']->value->getIdVenditore() && $_smarty_tpl->tpl_vars['userLogged']->value != 'admin') {?>
                                            <div class="d-flex justify-content-between align-items-center pb-2 mb-1">
                                                <a type="button"  href="/markethub/Annunci/schermataAcquisto?=<?php echo $_smarty_tpl->tpl_vars['annuncio']->value->getIdAnnuncio();?>
"   style="margin: auto; width: 50%" class="btn btn-primary">Acquista</a>
                                            </div>
                                        <?php } elseif ($_smarty_tpl->tpl_vars['mod']->value->getIdUser() == $_smarty_tpl->tpl_vars['annuncio']->value->getIdVenditore() && $_smarty_tpl->tpl_vars['userLogged']->value != 'admin') {?>
                                            <div class="d-flex justify-content-between align-items-center pb-2 mb-1">
                                                <button type="button" data-bs-toggle="modal" data-bs-target="#modifica" style="margin: auto; width: 50%" class="btn btn-primary">Modifica</button>
                                            </div>
                                        <?php } elseif ($_smarty_tpl->tpl_vars['mod']->value->getIdUser() != $_smarty_tpl->tpl_vars['annuncio']->value->getIdVenditore() && $_smarty_tpl->tpl_vars['userLogged']->value == 'admin') {?>
                                           <p></p>
                                        <?php }?>

                                    </div>
                                </div>
                            </div>
                            <div class="col">

                                <!-- venditore -->
                                <div class="card" style="width: 18rem;">
                                    <div class="card-body">
                                        <?php if ($_smarty_tpl->tpl_vars['userLogged']->value == 'logged') {?>
                                        <form class="form-inline" method="POST" action="/markethub/Utente/profiloLoggato?id=<?php echo $_smarty_tpl->tpl_vars['utente']->value->getIdUser();?>
">
                                            <?php } elseif ($_smarty_tpl->tpl_vars['userLogged']->value == 'admin') {?>
                                            <form class="form-inline" method="POST" action="/markethub/Admin/profiloUtente?id=<?php echo $_smarty_tpl->tpl_vars['utente']->value->getIdUser();?>
">
                                            <?php } else { ?>
                                            <form class="form-inline" method="POST" action="/markethub/Utente/profiloNonLoggato?id=<?php echo $_smarty_tpl->tpl_vars['utente']->value->getIdUser();?>
">
                                                <?php }?>
                                                <input type="text" hidden name="email" value="?" />
                                                <?php if ($_smarty_tpl->tpl_vars['fotoUtente']->value != null) {?>
                                                <input type="image" src="data:<?php echo $_smarty_tpl->tpl_vars['fotoUtente']->value->getTipo();?>
;base64,<?php echo $_smarty_tpl->tpl_vars['fotoUtente']->value->getFoto();?>
" style="border-radius: 50%;" width="90" height="90"/>
                                            </form>
                                            <?php } else { ?>
                                        <input type="image" src="/markethub/smarty/libs/images/login.png" style="border-radius: 50%;" width="90" height="90"/>
                                            <?php }?>
                                        </form>

                                        <p class="card-text"><?php echo $_smarty_tpl->tpl_vars['utente']->value->getNome();?>
 <?php echo $_smarty_tpl->tpl_vars['utente']->value->getCognome();?>
</p>

                                        <p class="card-text">Contatti: <?php echo $_smarty_tpl->tpl_vars['utente']->value->getEmail();?>
</p>
                                        <!--  <h6><img src="https://www.internetmatters.org/wp-content/uploads/2020/01/instagradientlogo-no-background.png" style="float: left;width: 25px;height: 25px;object-fit: cover; margin-right: 100%"> <?php echo $_smarty_tpl->tpl_vars['instagram']->value;?>
</h6>
                                        <h6><img src="https://www.facebook.com/images/fb_icon_325x325.png" style="float: left;width:  25px;height: 25px;object-fit: cover; margin-right: 100%"><?php echo $_smarty_tpl->tpl_vars['facebook']->value;?>
</h6>-->

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>
</div>
<!-- modal -->
<div class="modal fade" id="modifica" tabindex="-1" aria-labelledby="modificaLabel" role="dialog" aria-hidden="true">
    <form action="/markethub/Annunci/confermaModifiche?idAnnuncio=<?php echo $_smarty_tpl->tpl_vars['annuncio']->value->getIdAnnuncio();?>
" method="POST" enctype="multipart/form-data">

        <div class="modal-dialog modal-fullscreen">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modificaLabel">Modifica Annuncio</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form class="row g-3 needs-validation" novalidate>
                        <div class="col-mb-4">
                            <label for="validationCustom01" class="form-label">Titolo</label>
                            <input type="text" class="form-control" name="titolo" id="validationCustom02" style="background-color: whitesmoke" value="<?php echo $_smarty_tpl->tpl_vars['annuncio']->value->getTitolo();?>
" required>
                            <div class="valid-feedback">
                                Looks good!
                            </div>
                        </div>
                        <div class="col-1">
                            <label for="categoria">Categoria</label>
                            <select name="categoria" id="categoria" class="form-select">
                                <option value="--Seleziona--">--Seleziona--</option>

                                <?php if (is_array($_smarty_tpl->tpl_vars['tutteCategorie']->value)) {?>
                                    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['tutteCategorie']->value, 'cate');
$_smarty_tpl->tpl_vars['cate']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['cate']->value) {
$_smarty_tpl->tpl_vars['cate']->do_else = false;
?>
                                        <option id="categoria" name="categoria" value="<?php echo $_smarty_tpl->tpl_vars['cate']->value['idCate'];?>
"><?php echo $_smarty_tpl->tpl_vars['cate']->value['categoria'];?>
</option>
                                    <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                                <?php }?>


                            </select>
                        </div>
                        <div class="col-mb-4">
                            <label for="validationCustom03" class="form-label">Prezzo</label>
                            <input type="text" class="form-control" name="prezzo" id="validationCustom04" style="background-color: whitesmoke" value="<?php echo $_smarty_tpl->tpl_vars['annuncio']->value->getPrezzo();?>
" required>
                            <div class="valid-feedback">
                                Looks good!
                            </div>
                            <div class="col-mb-4">
                                <label for="validationCustom04" class="form-label">Descrizione</label>
                                <input type="text" class="form-control" name="descrizione" id="validationCustom05" style="background-color: whitesmoke" value="<?php echo $_smarty_tpl->tpl_vars['annuncio']->value->getDescrizione();?>
" required>
                                <div class="valid-feedback">
                                    Looks good!
                                </div>
                            </div>
                            <div class="mb-3">
                            <label for="file" class="form-label">Carica una nuova foto</label>
                            <input type="file" class="form-control"  id="file" name="file[]" multiple required >
                            </div>

                        </div>
                        <div class="col-12">
                            <input  class="btn btn-primary" type="submit" value="Applica modifica">
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                </div>
            </div>
        </div>
    </form>
</div>
<?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"><?php echo '</script'; ?>
>
</body>
</html><?php }
}
