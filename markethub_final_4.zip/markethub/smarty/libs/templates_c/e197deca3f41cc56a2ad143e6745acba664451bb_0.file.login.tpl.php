<?php
/* Smarty version 4.2.0, created on 2023-12-07 17:40:14
  from 'C:\xampp\htdocs\markethub\smarty\libs\templates\login.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.0',
  'unifunc' => 'content_6571f56e0a1c99_03290310',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e197deca3f41cc56a2ad143e6745acba664451bb' => 
    array (
      0 => 'C:\\xampp\\htdocs\\markethub\\smarty\\libs\\templates\\login.tpl',
      1 => 1701967211,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6571f56e0a1c99_03290310 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>

<?php $_smarty_tpl->_assignInScope('ban', (($tmp = $_smarty_tpl->tpl_vars['ban']->value ?? null)===null||$tmp==='' ? 0 ?? null : $tmp));
$_smarty_tpl->_assignInScope('error', (($tmp = $_smarty_tpl->tpl_vars['error']->value ?? null)===null||$tmp==='' ? '' ?? null : $tmp));
$_smarty_tpl->_assignInScope('emailExist', (($tmp = $_smarty_tpl->tpl_vars['emailExist']->value ?? null)===null||$tmp==='' ? '' ?? null : $tmp));
$_smarty_tpl->_assignInScope('emailRegex', (($tmp = $_smarty_tpl->tpl_vars['emailRegex']->value ?? null)===null||$tmp==='' ? '' ?? null : $tmp));
$_smarty_tpl->_assignInScope('password', (($tmp = $_smarty_tpl->tpl_vars['password']->value ?? null)===null||$tmp==='' ? '' ?? null : $tmp));
$_smarty_tpl->_assignInScope('vemail', (($tmp = $_smarty_tpl->tpl_vars['vemail']->value ?? null)===null||$tmp==='' ? null ?? null : $tmp));
$_smarty_tpl->_assignInScope('fine_ban', (($tmp = $_smarty_tpl->tpl_vars['fine_ban']->value ?? null)===null||$tmp==='' ? '' ?? null : $tmp));?>
<html lang="en" xmlns="http://www.w3.org/1999/html">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Market Hub - Login or Sign up</title>
    <link rel="icon" type="image/x-icon" href="/markethub/smarty/libs/images/shop.png" />
    <link rel="stylesheet" href="/markethub/smarty/libs/css/login.css">
    <link href='https://use.fontawesome.com/releases/v5.7.2/css/all.css' rel='stylesheet'>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
    <link href="/markethub/smarty/libs/css/style.css" rel="stylesheet">

    <?php echo '<script'; ?>
>
        function ready() {
            if (!navigator.cookieEnabled) {
                alert('Attenzione! Attivare i cookie per proseguire correttamente la navigazione');
            }
        }
    <?php echo '</script'; ?>
>


</head>

<body style="margin:0">

    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" role="dialog"
        aria-hidden="true">
        <form action="/markethub/Utente/registration" method="POST">
            <div class="modal-dialog modal-fullscreen">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Registrazione</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form class="row g-3 needs-validation" novalidate>
                            <div class="col-md-4">
                                <label for="validationCustom01" class="form-label">Nome</label>
                                <input type="text" class="form-control" name="nome" required>
                                <div class="valid-feedback">
                                    Looks good!
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label for="validationCustom02" class="form-label">Cognome</label>
                                <input type="text" class="form-control" name="cognome" value="" required>
                                <div class="valid-feedback">
                                    Looks good!
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label for="validationCustom02" class="form-label">Email</label>
                                <input type="text" class="form-control" name="email"
                                    pattern="[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$" 
                                    title="Deve essere inclusa una chiocciola @ per l'email" />
                                <div class="valid-feedback">
                                    Looks good!
                                </div>
                            </div>
                            <div class="col-md-6">

                                <label for="validationCustom03" class="form-label">Password</label>

                                <input type="password" class="form-control" id="pswq" name="password"
                                    pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" 
                                    title="La password deve contenere almeno 8 caratteri, di cui almeno una lettera maiuscola" />
                                <i type="checkbox" class="far fa-eye" id="togglePassword2"
                                    style="position: relative; left: 95%;bottom: 30px;cursor: pointer;"
                                    onclick="show('pswq')">
                                </i>
                            </div>
                            <div class="col-12">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="invalidCheck" required>
                                    <label class="form-check-label" for="invalidCheck">
                                        Agree to terms and conditions
                                    </label>
                                    <div class="invalid-feedback">
                                        You must agree before submitting.
                                    </div>
                                </div>
                            </div>
                            <div class="col-12">
                                <input class="btn btn-primary" type="submit" value="Registrati">
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">

                    </div>
                </div>
        </form>
    </div>
    </div>

    <?php if ($_smarty_tpl->tpl_vars['ban']->value == 1 && $_smarty_tpl->tpl_vars['fine_ban']->value != '') {?>
    <?php echo '<script'; ?>
>alert("Sei stato bannato fino al <?php echo $_smarty_tpl->tpl_vars['fine_ban']->value;?>
")<?php echo '</script'; ?>
>
    <?php }?>

    <?php if ($_smarty_tpl->tpl_vars['error']->value == 'errore') {?>
    <?php echo '<script'; ?>
>alert("Riprova l'accesso")<?php echo '</script'; ?>
>
    <?php }?>

    <?php if ($_smarty_tpl->tpl_vars['emailRegex']->value == 'errorRegex') {?>
    <?php echo '<script'; ?>
>alert("Email non valida")<?php echo '</script'; ?>
>
    <?php }?>
    <?php if ($_smarty_tpl->tpl_vars['password']->value == 'errorPassword') {?>
    <?php echo '<script'; ?>
>alert("Password non valida")<?php echo '</script'; ?>
>
    <?php }?>

    <?php if ($_smarty_tpl->tpl_vars['emailExist']->value == 'errorExist') {?>
    <?php echo '<script'; ?>
>alert("Email già esistente")<?php echo '</script'; ?>
>
    <?php }?>

    <main>

        <form method="POST" action="/markethub/Utente/login">
            <div class="row">
                <div class="colm-form">
                    <div class="form-container">
                        <input type="text" name="email" placeholder="Email address" value="">
                        <i type="checkbox" class="far fa-eye" id="togglePassword2"
                            style="position: relative; left: 40%;bottom: -40px;cursor: pointer;" onclick="show('psw')">
                        </i>
                        <input type="password" name="password" id="psw" placeholder="Password" value="">

                        <button id="index" class="btn-login">Login</button>
                        
                        <!--<button class="btn-new" onclick="location.href='./register.html'">Create new Account</button>-->
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-new" data-bs-toggle="modal" data-bs-target="#exampleModal">
                            Create new Account
                        </button>
        </form>
        <form style="color: #a94442" action="/markethub/">
            <input type="submit" value="Indietro" class="btn btn-new">
        </form>
        </div>
        </div>
        </div>
    </main>
    <?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8"
        crossorigin="anonymous"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="/markethub/smarty/libs/javascript/showpsw.js"><?php echo '</script'; ?>
>
</body>

</html><?php }
}
