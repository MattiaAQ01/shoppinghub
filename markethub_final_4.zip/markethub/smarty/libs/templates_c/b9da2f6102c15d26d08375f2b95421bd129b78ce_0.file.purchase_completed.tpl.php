<?php
/* Smarty version 4.2.0, created on 2023-12-07 17:56:43
  from 'C:\xampp\htdocs\markethub\smarty\libs\templates\purchase_completed.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.0',
  'unifunc' => 'content_6571f94b572db3_78581927',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b9da2f6102c15d26d08375f2b95421bd129b78ce' => 
    array (
      0 => 'C:\\xampp\\htdocs\\markethub\\smarty\\libs\\templates\\purchase_completed.tpl',
      1 => 1701689695,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6571f94b572db3_78581927 (Smarty_Internal_Template $_smarty_tpl) {
?><!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Market Hub - Purchase Completed</title>
    <link rel="icon" type="image/x-icon" href="/markethub/smarty/libs/images/shop.png" />
    <link href="/markethub/smarty/libs/css/purchase.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <link href="/markethub/smarty/libs/css/style.css" rel="stylesheet">
</head>

<body>
    <div class="container text-center">
        <h4>Grazie per aver scelto Market Hub!</h4>
        <p>Il tuo acquisto è andato a buon fine</p>
        <a href="/markethub/">Torna alla homepage</a>
    </div>

</body>
<?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3"
    crossorigin="anonymous"><?php echo '</script'; ?>
>
</body>

</html><?php }
}
