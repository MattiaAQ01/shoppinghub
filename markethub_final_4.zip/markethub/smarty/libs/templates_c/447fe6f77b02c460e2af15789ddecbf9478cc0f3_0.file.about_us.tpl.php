<?php
/* Smarty version 4.2.0, created on 2023-12-04 13:11:31
  from 'C:\xampp\htdocs\markethub\smarty\libs\templates\about_us.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.0',
  'unifunc' => 'content_656dc1f31e6df2_21586056',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '447fe6f77b02c460e2af15789ddecbf9478cc0f3' => 
    array (
      0 => 'C:\\xampp\\htdocs\\markethub\\smarty\\libs\\templates\\about_us.tpl',
      1 => 1701690889,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
  ),
),false)) {
function content_656dc1f31e6df2_21586056 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Market Hub - About us</title>
  <link rel="icon" type="image/x-icon" href="/markethub/smarty/libs/images/shop.jpg" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  <link href="/markethub/smarty/libs/css/style.css" rel="stylesheet" />
  <link href='https://fonts.googleapis.com/css?family=Open+Sans:700,800,400' rel='stylesheet' type='text/css' />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css" />

</head>
<style>
  body {
    font-family: Arial, Helvetica, sans-serif;
    margin: 0;
  }

  html {
    box-sizing: border-box;
  }

  *,
  *:before,
  *:after {
    box-sizing: inherit;
  }

  .column {
    float: left;
    width: 33.3%;
    margin-bottom: 16px;
    padding: 0 8px;
  }

  .card {
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
    margin: 8px;
  }

  .about-section {
    padding: 50px;
    text-align: center;
    background-color: #0dcaf0;
    color: black;
    font-size: 30px;
  }

  .container {
    padding: 0 16px;
  }

  .container::after,
  .row::after {
    content: "";
    clear: both;
    display: table;
  }

  .title {
    color: grey;
  }

  .button {
    border: none;
    outline: 0;
    display: inline-block;
    padding: 8px;
    color: white;
    background-color: #000;
    text-align: center;
    cursor: pointer;
    width: 100%;
  }

  .button:hover {
    background-color: #555;
  }

  @media screen and (max-width: 650px) {
    .column {
      width: 100%;
      display: block;
    }
  }
</style>


<?php $_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<body>
  <div class="about-section">
    <h1></h1>
    <p>Benvenuto sul nostro sito! Qui trovi i nostri contatti personali.</p>
  </div>

  <h2 style="text-align:center"></h2>
  <div class="row">
    <div class="column">
      <div class="card">
        <img src="/markethub/smarty/libs/images/mattia.jpg" style="width:100%">
        <div class="container">
          <h2>Burtini Mattia</h2>
          <p class="title">Co-Creator</p>
          <p>Studente di Ingegneria Informatica presso Università degli studi dell'Aquila</p>
          <p>mattia.burtini@student.univaq.it</p>
          <p><a href="https://www.facebook.com/milito.italia" class="button">Contact</a></p>
        </div>
      </div>
    </div>

    <div class="column">
      <div class="card">
        <img src="/markethub/smarty/libs/images/matteo.jpg" style="width:100%">
        <div class="container">
          <h2>Paolino Matteo</h2>
          <p class="title">Co-Creator</p>
          <p>Studente di Ingegneria Informatica presso Università degli studi dell'Aquila</p>
          <p>matteo.paolino@student.univaq.it</p>
          <p><a href="https://www.facebook.com/matteo.paolino.79" class="button">Contact</a></p>
        </div>
      </div>
    </div>

    <div class="column">
      <div class="card">
        <img src="/markethub/smarty/libs/images/antonello.jpeg" style="width:100%">
        <div class="container">
          <h2>Tagliente Antonello</h2>
          <p class="title">Co-Creator</p>
          <p>Studente di Ingegneria Informatica presso Università degli studi dell'Aquila</p>
          <p>antonello.tagliente@student.univaq.it</p>
          <p><a href="https://www.instagram.com/antonello.tagliente33/" class="button">Contact</a></p>
        </div>
      </div>
    </div>
  </div>


  <footer class="bg-info py-4 mt-auto">
    <div class="container px-5">
      <div class="row align-items-center justify-content-between flex-column flex-sm-row">
        <div class="col-auto">
          <div class="small m-0">Copyright &copy; Market Hub 2023</div>
        </div>
        <div class="col-auto">
        </div>
      </div>
    </div>
  </footer>

</body>

</html><?php }
}
