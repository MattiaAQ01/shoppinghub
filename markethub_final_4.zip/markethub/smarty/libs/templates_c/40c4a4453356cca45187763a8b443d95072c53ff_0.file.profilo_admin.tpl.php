<?php
/* Smarty version 4.2.0, created on 2023-12-13 12:24:17
  from 'C:\xampp\htdocs\markethub\smarty\libs\templates\profilo_admin.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.0',
  'unifunc' => 'content_65799461411ad5_56330687',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '40c4a4453356cca45187763a8b443d95072c53ff' => 
    array (
      0 => 'C:\\xampp\\htdocs\\markethub\\smarty\\libs\\templates\\profilo_admin.tpl',
      1 => 1702419461,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_65799461411ad5_56330687 (Smarty_Internal_Template $_smarty_tpl) {
?><!doctype html>
<?php $_smarty_tpl->_assignInScope('facebook', (($tmp = $_smarty_tpl->tpl_vars['facebook']->value ?? null)===null||$tmp==='' ? '' ?? null : $tmp));
$_smarty_tpl->_assignInScope('instagram', (($tmp = $_smarty_tpl->tpl_vars['instagram']->value ?? null)===null||$tmp==='' ? '' ?? null : $tmp));
$_smarty_tpl->_assignInScope('luogo', (($tmp = $_smarty_tpl->tpl_vars['luogo']->value ?? null)===null||$tmp==='' ? '' ?? null : $tmp));
$_smarty_tpl->_assignInScope('userLogged', (($tmp = $_smarty_tpl->tpl_vars['userLogged']->value ?? null)===null||$tmp==='' ? 'nouser' ?? null : $tmp));?>


<html lang="en" xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Market Hub - Profilo Utente Admin</title>
    <link rel="icon" type="image/x-icon" href="/markethub/smarty/libs/images/shop.png" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <link href="/markethub/smarty/libs/css/style.css" rel="stylesheet">
    <?php echo '<script'; ?>
 src="https://code.jquery.com/jquery-1.10.2.js"><?php echo '</script'; ?>
>
    <link href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css' rel='stylesheet'>
    <?php echo '<script'; ?>
 type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'><?php echo '</script'; ?>
>
    <link href="/markethub/smarty/libs/css/recensione.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">



</head>

<body style="margin-top: 70px">




    <?php $_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


    <div class="container">
        <div class="main-body">
            <!-- /Breadcrumb -->
            <div class="row gutters-sm">
                <div class="col-md-4 mb-3">
                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex flex-column align-items-center text-center">

                                <?php if ((isset($_smarty_tpl->tpl_vars['foto_utente']->value))) {?>
                                <img src="data:<?php echo $_smarty_tpl->tpl_vars['foto_utente']->value->getTipo();?>
;;base64,<?php echo $_smarty_tpl->tpl_vars['foto_utente']->value->getFoto();?>
" alt="Admin"
                                    class="rounded-circle" width="140">


                                <?php } else { ?>
                                <img src="/markethub/smarty/libs/images/login.png" alt="Admin" class="rounded-circle"
                                    width="140">

                                <?php }?>
                                <div class="mt-3">
                                    <h4><?php echo $_smarty_tpl->tpl_vars['utente']->value->getNome();?>
</h4>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="col-md-8">
                    <div class="card mb-3">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-sm-3">
                                    <h6 class="mb-0">Nome</h6>
                                </div>
                                <div class="col-sm-9 text-secondary">
                                    <?php echo $_smarty_tpl->tpl_vars['utente']->value->getNome();?>

                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-sm-3">
                                    <h6 class="mb-0">Cognome</h6>
                                </div>
                                <div class="col-sm-9 text-secondary">
                                    <?php echo $_smarty_tpl->tpl_vars['utente']->value->getCognome();?>

                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-sm-3">
                                    <h6 class="mb-0">Email</h6>
                                </div>
                                <div class="col-sm-9 text-secondary">
                                    <?php echo $_smarty_tpl->tpl_vars['utente']->value->getEmail();?>

                                </div>
                            </div>
                            <hr>
                            <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                data-bs-target="#modifica">
                                Modifica
                            </button>

                        </div>
                    </div>
                </div>

            </div>
        </div>

        </section>
        <?php echo '<script'; ?>
 type='text/javascript'
            src='https://stackpath.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.bundle.min.js'><?php echo '</script'; ?>
>
        <?php echo '<script'; ?>
 type='text/javascript' src='#'><?php echo '</script'; ?>
>
        <?php echo '<script'; ?>
 type='text/javascript' src='#'><?php echo '</script'; ?>
>
        <?php echo '<script'; ?>
 type='text/javascript' src='#'><?php echo '</script'; ?>
>
        <?php echo '<script'; ?>
 type='text/javascript' src='#'><?php echo '</script'; ?>
>
        <?php echo '<script'; ?>
 type='text/javascript'>var myLink = document.querySelector('a[href="#"]');
            myLink.addEventListener('click', function (e) {
                e.preventDefault();
            });<?php echo '</script'; ?>
>
    </div>
    </div>
    </section>


    </main>



    <!-- modifica -->

    <div class="modal fade" id="modifica" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <form action="/markethub/Utente/modificaP?id=<?php echo $_smarty_tpl->tpl_vars['utente']->value->getIdUser();?>
" method="post"
            enctype="multipart/form-data">
            <div class="modal-dialog modal-fullscreen">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modificaLabel">Modifica profilo</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form class="row g-3 needs-validation" novalidate>
                            <div class="col-mb-4">
                                <label for="validationCustom01" class="form-label">Nome</label>
                                <input type="text" class="form-control" name="nome" id="nome"
                                    style="background-color: whitesmoke" value="<?php echo $_smarty_tpl->tpl_vars['utente']->value->getNome();?>
">

                            </div>
                            <div class="col-mb-4">
                                <label for="validationCustom02" class="form-label">Cognome</label>
                                <input type="text" class="form-control" name="cognome" id="cognome"
                                    style="background-color: whitesmoke" value="<?php echo $_smarty_tpl->tpl_vars['utente']->value->getCognome();?>
">

                            </div>
                            <div class="col-mb-4">
                                <label for="validationCustom03" class="form-label">Email</label>
                                <input type="text" class="form-control" name="email" id="email"
                                    style="background-color: whitesmoke" value="<?php echo $_smarty_tpl->tpl_vars['utente']->value->getEmail();?>
">
                            </div>

                            <div class="col-mb-4">
                                <label for="validationCustom03" class="form-label">Password</label>
                                <input type="password" class="form-control" name="password" id="password"
                                    style="background-color: whitesmoke" value="<?php echo $_smarty_tpl->tpl_vars['utente']->value->getPassword();?>
">
                            </div>

                            <div class="col-mb-4">
                                <label for="file" class="form-label">Carica una nuova foto</label>
                                <input type="file" class="form-control" id="file" name="file">
                            </div>
                            <div class="col-12">
                                <button class="btn btn-primary" type="submit">Applica modifiche</button>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                    </div>
                </div>
            </div>
        </form>
        <?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
        <?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3"
            crossorigin="anonymous"><?php echo '</script'; ?>
>
</body>

</html><?php }
}
