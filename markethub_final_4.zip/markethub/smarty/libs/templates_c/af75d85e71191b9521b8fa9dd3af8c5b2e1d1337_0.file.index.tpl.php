<?php
/* Smarty version 4.2.0, created on 2023-12-12 19:53:14
  from 'C:\xampp\htdocs\markethub\smarty\libs\templates\index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.0',
  'unifunc' => 'content_6578ac1af044e1_84687831',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'af75d85e71191b9521b8fa9dd3af8c5b2e1d1337' => 
    array (
      0 => 'C:\\xampp\\htdocs\\markethub\\smarty\\libs\\templates\\index.tpl',
      1 => 1702407192,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_6578ac1af044e1_84687831 (Smarty_Internal_Template $_smarty_tpl) {
?><!doctype html>
<?php $_smarty_tpl->_assignInScope('userLogged', (($tmp = $_smarty_tpl->tpl_vars['userLogged']->value ?? null)===null||$tmp==='' ? 'nouser' ?? null : $tmp));?>

<html lang="en" xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html"/>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Market Hub - Homepage</title>
    <link rel="icon" type="image/x-icon" href="/markethub/smarty/libs/images/shop.png" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <link href="/markethub/smarty/libs/css/style.css" rel="stylesheet" />
    <?php echo '<script'; ?>
 src="https://code.jquery.com/jquery-1.10.2.js"><?php echo '</script'; ?>
>


    <?php echo '<script'; ?>
>
        function ready(){
            if(!navigator.cookieEnabled){
                alert('Attenzione! Attivare i cookie per proseguire correttamente la navigazione')
            }
        }
        document.addEventListener("DOMContentLoaded",ready);
    <?php echo '</script'; ?>
>

</head>
<body>


<?php $_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
    <style>
        .carousel-inner {
            position: relative;
            overflow: hidden;
        }

        .carousel-item img {
            transition: transform 1s ease-in-out;
        }

        
        .scroll-down .carousel-item img {
            transform: scale(0.5); 
        }
    </style>

<div id="carouselHome" class="carousel slide carousel-fade" data-bs-ride="carousel" style="margin-top: -50px;">
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img src="/markethub/smarty/libs/images/copertina.jpg" class="d-block w-100" alt="...">

    </div>

</div>
 <?php echo '<script'; ?>
>
        window.addEventListener('scroll', function() {
            var scrollPosition = window.scrollY;
            var scrollDownClass = 'scroll-down';
            
            
            if (scrollPosition > 0) {
                document.body.classList.add(scrollDownClass);
            } else {
                document.body.classList.remove(scrollDownClass);
            }
        });
    <?php echo '</script'; ?>
>
<div class="container my-15 text-center">
    <div class="container"  style="display: compact;align-items: center;" >
       

        <h1 class="header_top">Benvenuto su MARKET HUB!</h1>
    </div>





</div>
<section class="banner_main" >
    <div class="container">
        <div class="row">
            <div class="col-md-8 mx-auto text-center">
                <div class="text-bg">
                    <?php if ((isset($_smarty_tpl->tpl_vars['annunci_home']->value))) {?>

                    <a href="Annunci/esploraAnnunci" type="button" class="btn bg-info">Tutti gli annunci</a>


                </div>
            </div>

        </div>
    </div>
</section>
<p></p>
<section class="py-5">
    <div id="shopnow" class="container px-5 my-5">
        <div class="row gx-5 justify-content-around">
            <div class="col-lg-8 col-xl-6">
                <div class="text-center">
                    <h2 class="fw-bolder mb-5">Annunci più popolari</h2>
                </div>
            </div>
        </div>
        <div class=" row gx-2 ">
            <?php if (is_array($_smarty_tpl->tpl_vars['annunci_home']->value) && is_array($_smarty_tpl->tpl_vars['annunci_foto']->value)) {?>
                <?php
$_smarty_tpl->tpl_vars['i'] = new Smarty_Variable(null, $_smarty_tpl->isRenderingCache);
$_smarty_tpl->tpl_vars['i']->value = 0;
if ($_smarty_tpl->tpl_vars['i']->value < sizeof($_smarty_tpl->tpl_vars['annunci_home']->value)) {
for ($_foo=true;$_smarty_tpl->tpl_vars['i']->value < sizeof($_smarty_tpl->tpl_vars['annunci_home']->value); $_smarty_tpl->tpl_vars['i']->value++) {
?>
                    <div id="annunci" class="col-lg-4 mb-5">
                        <div class="row" style="width: 14rem; height: 14rem; margin-left: auto; margin-right: auto;">
                            <div class="card  h-100 shadow border-0"  >
                                <img class="card-img-top same" src="data:<?php echo $_smarty_tpl->tpl_vars['annunci_foto']->value[$_smarty_tpl->tpl_vars['i']->value][0]->getTipo();?>
;base64,<?php echo $_smarty_tpl->tpl_vars['annunci_foto']->value[$_smarty_tpl->tpl_vars['i']->value][0]->getFoto();?>
" style="width: 200px; height: 150px; align-content: center" />
                                <div class="card-body p-4">
                                    <h5 class="card-title"><?php echo $_smarty_tpl->tpl_vars['annunci_home']->value[$_smarty_tpl->tpl_vars['i']->value]->getTitolo();?>
</h5>
                                    <a methods="POST"  class="stretched-link" href="Annunci/infoAnnuncio?id=<?php echo $_smarty_tpl->tpl_vars['annunci_home']->value[$_smarty_tpl->tpl_vars['i']->value]->getIdAnnuncio();?>
" ></a>

                                </div>
                            </div>
                            <p></p>

                        </div>
                    </div>
                <?php }
}
?>
            <?php }?>
        </div>
    </div>
    
    <?php } else { ?>
    <h2 class="fw-bolder mb-5">Al momento non ci sono annunci da visualizzare</h2>
    <?php }?>
</section>
<?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>



    <?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"><?php echo '</script'; ?>
>
</body>
</html><?php }
}
