<?php

//definisce le credenziali di accesso al database.

$GLOBALS['database']='markethub';
$GLOBALS['username']='root';
$GLOBALS['password']='pippo';
?>